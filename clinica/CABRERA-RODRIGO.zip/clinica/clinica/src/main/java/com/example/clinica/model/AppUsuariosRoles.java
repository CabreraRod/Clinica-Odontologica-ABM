package com.example.clinica.model;

public enum AppUsuariosRoles {
    ROLE_USER, ROLE_ADMIN
}
